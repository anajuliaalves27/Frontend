<?php
require_once 'config.php';
verificarLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: locacoes.php');
    exit;
}

$conn = conectar();

$locacao_id    = (int)($_POST['locacao_id']    ?? 0);
$dispositivo_id= (int)($_POST['dispositivo_id'] ?? 0);
$data_devolucao= sanitizar($conn, $_POST['data_devolucao'] ?? '');
$houve_dano    = (int)($_POST['houve_dano']    ?? 0);
$data_retirada = sanitizar($conn, $_POST['data_retirada']  ?? '');
$data_prevista = sanitizar($conn, $_POST['data_prevista']  ?? '');
$valor_diaria  = floatval($_POST['valor_diaria'] ?? 0);

// Validações
if ($locacao_id <= 0 || empty($data_devolucao)) {
    $conn->close();
    header("Location: devolucao.php?id=$locacao_id&erro_msg=Preencha+todos+os+campos.");
    exit;
}

if ($data_devolucao < $data_retirada) {
    $conn->close();
    header("Location: devolucao.php?id=$locacao_id&erro_msg=A+data+de+devolução+não+pode+ser+anterior+à+data+de+retirada.");
    exit;
}

// Verifica se a locação ainda está ativa
$res = $conn->query("SELECT id FROM locacoes WHERE id=$locacao_id AND status='ativa' LIMIT 1");
if (!$res || $res->num_rows === 0) {
    $conn->close();
    header('Location: locacoes.php?erro_msg=Locação+não+encontrada+ou+já+finalizada.');
    exit;
}

// Cálculo dos valores
$diasReais   = calcularDias($data_retirada, $data_devolucao);
$valorBase   = $diasReais * $valor_diaria;

// Multa por atraso
$multaAtraso = 0;
if ($data_devolucao > $data_prevista) {
    $diasAtraso  = calcularDias($data_prevista, $data_devolucao);
    $multaAtraso = $diasAtraso * $valor_diaria * MULTA_DIARIA_ATRASO;
}

// Taxa por dano
$taxaDano = ($houve_dano == 1) ? TAXA_DANO : 0;

$valorTotal = $valorBase + $multaAtraso + $taxaDano;

// Atualiza a locação
$sql = "UPDATE locacoes SET
            data_devolucao = '$data_devolucao',
            houve_dano     = $houve_dano,
            valor_total    = $valorTotal,
            multa_atraso   = $multaAtraso,
            taxa_dano      = $taxaDano,
            status         = 'finalizada'
        WHERE id = $locacao_id";

if ($conn->query($sql)) {
    // Libera o dispositivo
    $conn->query("UPDATE dispositivos SET status='disponivel' WHERE id=$dispositivo_id");
    $conn->close();
    header('Location: locacoes.php?msg=Devolução+registrada+com+sucesso.');
} else {
    $conn->close();
    header("Location: devolucao.php?id=$locacao_id&erro_msg=Erro+ao+registrar+devolução.");
}
exit;
?>
