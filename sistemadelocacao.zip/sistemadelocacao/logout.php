<?php
require_once 'config.php';
session_destroy();
header('Location: loguin.php');
exit;
?>
