<?php
require_once 'config.php';
verificarLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: locacoes.php');
    exit;
}

$conn = conectar();
$acao = $_POST['acao'] ?? '';

if ($acao === 'registrar') {
    $nome_cliente              = sanitizar($conn, $_POST['nome_cliente'] ?? '');
    $dispositivo_id            = (int)($_POST['dispositivo_id'] ?? 0);
    $data_retirada             = sanitizar($conn, $_POST['data_retirada'] ?? '');
    $data_prevista_devolucao   = sanitizar($conn, $_POST['data_prevista_devolucao'] ?? '');

    // Validação de campos vazios
    if (empty($nome_cliente) || $dispositivo_id <= 0 || empty($data_retirada) || empty($data_prevista_devolucao)) {
        $conn->close();
        header('Location: locacoes.php?acao=nova&erro_msg=Preencha+todos+os+campos.');
        exit;
    }

    // Validação de datas
    if ($data_prevista_devolucao < $data_retirada) {
        $conn->close();
        header('Location: locacoes.php?acao=nova&erro_msg=A+data+de+devolução+não+pode+ser+anterior+à+data+de+retirada.');
        exit;
    }

    // Verifica se o dispositivo existe e está disponível
    $res  = $conn->query("SELECT * FROM dispositivos WHERE id=$dispositivo_id LIMIT 1");
    $disp = $res ? $res->fetch_assoc() : null;

    if (!$disp) {
        $conn->close();
        header('Location: locacoes.php?acao=nova&erro_msg=Dispositivo+não+encontrado.');
        exit;
    }

    if ($disp['status'] !== 'disponivel') {
        $conn->close();
        header('Location: locacoes.php?acao=nova&erro_msg=Este+dispositivo+já+está+alugado.');
        exit;
    }

    // Registra a locação
    $sql = "INSERT INTO locacoes (nome_cliente, dispositivo_id, data_retirada, data_prevista_devolucao, status)
            VALUES ('$nome_cliente', $dispositivo_id, '$data_retirada', '$data_prevista_devolucao', 'ativa')";

    if ($conn->query($sql)) {
        // Atualiza status do dispositivo para alugado
        $conn->query("UPDATE dispositivos SET status='alugado' WHERE id=$dispositivo_id");
        $conn->close();
        header('Location: locacoes.php?msg=Locação+registrada+com+sucesso.');
    } else {
        $conn->close();
        header('Location: locacoes.php?acao=nova&erro_msg=Erro+ao+registrar+locação.');
    }
    exit;
}

$conn->close();
header('Location: locacoes.php');
exit;
?>
