<?php
require_once 'config.php';
verificarLogin();

$conn = conectar();
$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$hoje = date('Y-m-d');

if ($id <= 0) {
    header('Location: locacoes.php');
    exit;
}

// Busca a locação com dados do dispositivo
$res = $conn->query("
    SELECT l.*, d.modelo, d.marca, d.valor_diaria
    FROM locacoes l
    JOIN dispositivos d ON l.dispositivo_id = d.id
    WHERE l.id = $id AND l.status = 'ativa'
    LIMIT 1
");

$locacao = $res ? $res->fetch_assoc() : null;

if (!$locacao) {
    $conn->close();
    header('Location: locacoes.php?erro_msg=Locação+não+encontrada+ou+já+finalizada.');
    exit;
}

// Cálculo estimado
$diasPrevistos  = calcularDias($locacao['data_retirada'], $locacao['data_prevista_devolucao']);
$diasReais      = calcularDias($locacao['data_retirada'], $hoje);
$atrasado       = $hoje > $locacao['data_prevista_devolucao'];
$diasAtraso     = $atrasado ? calcularDias($locacao['data_prevista_devolucao'], $hoje) : 0;
$valorBase      = $diasReais * $locacao['valor_diaria'];
$multaAtraso    = $atrasado ? ($diasAtraso * $locacao['valor_diaria'] * MULTA_DIARIA_ATRASO) : 0;

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Devolução — ConectaFácil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
    <div class="page-header">
        <h2>Registrar Devolução</h2>
        <a href="locacoes.php" class="btn btn-secondary">← Voltar</a>
    </div>

    <?php if (isset($_GET['erro_msg'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_GET['erro_msg']) ?></div>
    <?php endif; ?>

    <!-- Resumo da locação -->
    <div class="info-card">
        <h3>Resumo da Locação #<?= $locacao['id'] ?></h3>
        <div class="info-grid">
            <div class="info-item">
                <span class="info-label">Cliente</span>
                <span class="info-value"><?= htmlspecialchars($locacao['nome_cliente']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Dispositivo</span>
                <span class="info-value"><?= htmlspecialchars($locacao['marca'] . ' ' . $locacao['modelo']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Data de Retirada</span>
                <span class="info-value"><?= formatarData($locacao['data_retirada']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Devolução Prevista</span>
                <span class="info-value">
                    <?= formatarData($locacao['data_prevista_devolucao']) ?>
                    <?php if ($atrasado): ?>
                        <span class="badge badge-red">ATRASO de <?= $diasAtraso ?> dia(s)</span>
                    <?php endif; ?>
                </span>
            </div>
            <div class="info-item">
                <span class="info-label">Valor da Diária</span>
                <span class="info-value"><?= formatarMoeda($locacao['valor_diaria']) ?></span>
            </div>
            <div class="info-item">
                <span class="info-label">Dias Utilizados (até hoje)</span>
                <span class="info-value"><?= $diasReais ?> dia(s)</span>
            </div>
        </div>
    </div>

    <!-- Formulário de devolução -->
    <div class="form-card">
        <form action="devolucao_action.php" method="POST" id="formDevolucao">
            <input type="hidden" name="locacao_id" value="<?= $locacao['id'] ?>">
            <input type="hidden" name="dispositivo_id" value="<?= $locacao['dispositivo_id'] ?>">
            <input type="hidden" name="data_retirada" value="<?= $locacao['data_retirada'] ?>">
            <input type="hidden" name="data_prevista" value="<?= $locacao['data_prevista_devolucao'] ?>">
            <input type="hidden" name="valor_diaria" value="<?= $locacao['valor_diaria'] ?>">

            <div class="form-group">
                <label for="data_devolucao">Data de Devolução *</label>
                <input type="date" id="data_devolucao" name="data_devolucao" required
                       value="<?= $hoje ?>"
                       min="<?= $locacao['data_retirada'] ?>">
            </div>

            <div class="form-group">
                <label>Houve dano ao aparelho? *</label>
                <div class="radio-group">
                    <label class="radio-label">
                        <input type="radio" name="houve_dano" value="0" checked> Não
                    </label>
                    <label class="radio-label">
                        <input type="radio" name="houve_dano" value="1"> Sim
                        <small>(taxa adicional de <?= formatarMoeda(TAXA_DANO) ?>)</small>
                    </label>
                </div>
            </div>

            <!-- Preview do cálculo -->
            <div class="calculo-preview" id="calculoPreview">
                <h4>💰 Cálculo do Valor</h4>
                <table class="table-calculo">
                    <tr>
                        <td>Dias utilizados:</td>
                        <td id="calcDias"><?= $diasReais ?></td>
                    </tr>
                    <tr>
                        <td>Valor base (<span id="calcDiasLabel"><?= $diasReais ?></span> × <?= formatarMoeda($locacao['valor_diaria']) ?>):</td>
                        <td id="calcBase"><?= formatarMoeda($valorBase) ?></td>
                    </tr>
                    <tr id="rowMulta" style="<?= $atrasado ? '' : 'display:none' ?>; color:#e74c3c;">
                        <td>Multa por atraso (<span id="calcDiasAtraso"><?= $diasAtraso ?></span> dia(s) × 10%):</td>
                        <td id="calcMulta"><?= formatarMoeda($multaAtraso) ?></td>
                    </tr>
                    <tr id="rowDano" style="display:none; color:#e74c3c;">
                        <td>Taxa por dano:</td>
                        <td><?= formatarMoeda(TAXA_DANO) ?></td>
                    </tr>
                    <tr class="calculo-total">
                        <td><strong>TOTAL:</strong></td>
                        <td id="calcTotal"><strong><?= formatarMoeda($valorBase + $multaAtraso) ?></strong></td>
                    </tr>
                </table>
            </div>

            <!-- Campos ocultos para enviar os valores calculados -->
            <input type="hidden" name="valor_total_base" id="hiddenBase" value="<?= $valorBase ?>">
            <input type="hidden" name="multa_atraso"     id="hiddenMulta" value="<?= $multaAtraso ?>">
            <input type="hidden" name="taxa_dano"        id="hiddenDano" value="0">
            <input type="hidden" name="valor_total"      id="hiddenTotal" value="<?= $valorBase + $multaAtraso ?>">

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">✅ Confirmar Devolução</button>
                <a href="locacoes.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>
</div>

<script>
// Dados para o cálculo dinâmico
const valorDiaria      = <?= $locacao['valor_diaria'] ?>;
const dataPrevista     = '<?= $locacao['data_prevista_devolucao'] ?>';
const dataRetirada     = '<?= $locacao['data_retirada'] ?>';
const taxaDano         = <?= TAXA_DANO ?>;
const multaDiariaPerc  = <?= MULTA_DIARIA_ATRASO ?>;
</script>
<script src="script.js"></script>
</body>
</html>
