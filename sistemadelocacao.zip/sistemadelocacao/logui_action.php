<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: loguin.php');
    exit;
}

$email = trim($_POST['email'] ?? '');
$senha = trim($_POST['senha'] ?? '');

if (empty($email) || empty($senha)) {
    header('Location: loguin.php?erro=campos');
    exit;
}

$conn = conectar();
$emailSafe = sanitizar($conn, $email);

// Busca só pelo email, ignora a senha por enquanto
$sql = "SELECT id, nome, email, senha, perfil FROM usuarios WHERE email = '$emailSafe' LIMIT 1";
$result = $conn->query($sql);

if ($result && $result->num_rows === 1) {
    $usuario = $result->fetch_assoc();

    // Aceita senha em texto puro OU hash (compatibilidade)
    $senhaOk = ($senha === $usuario['senha']) || password_verify($senha, $usuario['senha']);

    if ($senhaOk) {
        $_SESSION['usuario_id']     = $usuario['id'];
        $_SESSION['usuario_nome']   = $usuario['nome'];
        $_SESSION['usuario_email']  = $usuario['email'];
        $_SESSION['usuario_perfil'] = $usuario['perfil'];

        // Atualiza a senha para texto puro no banco
        $senhaSafe = sanitizar($conn, $senha);
        $conn->query("UPDATE usuarios SET senha = '$senhaSafe' WHERE id = " . $usuario['id']);

        $conn->close();
        header('Location: index.php');
        exit;
    }
}

$conn->close();
header('Location: loguin.php?erro=credenciais');
exit;
?>
