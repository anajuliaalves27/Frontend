<?php
require_once 'config.php';
verificarLogin();

$conn = conectar();
$acao = $_GET['acao'] ?? 'listar';
$id   = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Apenas admin pode cadastrar/editar/remover
$isAdmin = $_SESSION['usuario_perfil'] === 'admin';

// Buscar dispositivo para edição
$dispositivo = null;
if ($acao === 'editar' && $id > 0) {
    if (!$isAdmin) { header('Location: index.php?erro=acesso_negado'); exit; }
    $res = $conn->query("SELECT * FROM dispositivos WHERE id = $id LIMIT 1");
    $dispositivo = $res ? $res->fetch_assoc() : null;
    if (!$dispositivo) { header('Location: dispositivos.php'); exit; }
}

// Filtro de status
$filtro = $_GET['filtro'] ?? 'todos';
$where  = '';
if ($filtro === 'disponivel') $where = "WHERE status = 'disponivel'";
if ($filtro === 'alugado')    $where = "WHERE status = 'alugado'";

$dispositivos = $conn->query("SELECT * FROM dispositivos $where ORDER BY marca, modelo");

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dispositivos — ConectaFácil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">

    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['erro_msg'])): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($_GET['erro_msg']) ?></div>
    <?php endif; ?>

    <?php if (($acao === 'novo' || $acao === 'editar') && $isAdmin): ?>
    <!-- Formulário de cadastro/edição -->
    <div class="page-header">
        <h2><?= $acao === 'editar' ? 'Editar Dispositivo' : 'Cadastrar Dispositivo' ?></h2>
        <a href="dispositivos.php" class="btn btn-secondary">← Voltar</a>
    </div>

    <div class="form-card">
        <form action="dispositivo_action.php" method="POST" id="formDispositivo">
            <input type="hidden" name="acao" value="<?= $acao === 'editar' ? 'editar' : 'cadastrar' ?>">
            <?php if ($acao === 'editar'): ?>
                <input type="hidden" name="id" value="<?= $dispositivo['id'] ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="form-group">
                    <label for="marca">Marca *</label>
                    <input type="text" id="marca" name="marca" maxlength="100" required
                           value="<?= htmlspecialchars($dispositivo['marca'] ?? '') ?>"
                           placeholder="Ex: Samsung, Apple, Motorola">
                </div>
                <div class="form-group">
                    <label for="modelo">Modelo *</label>
                    <input type="text" id="modelo" name="modelo" maxlength="100" required
                           value="<?= htmlspecialchars($dispositivo['modelo'] ?? '') ?>"
                           placeholder="Ex: Galaxy S23, iPhone 14">
                </div>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="valor_diaria">Valor da Diária (R$) *</label>
                    <input type="number" id="valor_diaria" name="valor_diaria" step="0.01" min="0.01" required
                           value="<?= htmlspecialchars($dispositivo['valor_diaria'] ?? '') ?>"
                           placeholder="0,00">
                </div>
                <?php if ($acao === 'editar'): ?>
                <div class="form-group">
                    <label for="status">Status *</label>
                    <select id="status" name="status" required>
                        <option value="disponivel" <?= ($dispositivo['status'] ?? '') === 'disponivel' ? 'selected' : '' ?>>Disponível</option>
                        <option value="alugado"    <?= ($dispositivo['status'] ?? '') === 'alugado'    ? 'selected' : '' ?>>Alugado</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">
                    <?= $acao === 'editar' ? '💾 Salvar Alterações' : '➕ Cadastrar Dispositivo' ?>
                </button>
                <a href="dispositivos.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
    </div>

    <?php else: ?>
    <!-- Listagem de dispositivos -->
    <div class="page-header">
        <h2>Dispositivos</h2>
        <?php if ($isAdmin): ?>
            <a href="dispositivos.php?acao=novo" class="btn btn-primary">➕ Novo Dispositivo</a>
        <?php endif; ?>
    </div>

    <!-- Filtros -->
    <div class="filtros">
        <a href="dispositivos.php?filtro=todos"       class="btn btn-filter <?= $filtro === 'todos'      ? 'active' : '' ?>">Todos</a>
        <a href="dispositivos.php?filtro=disponivel"  class="btn btn-filter <?= $filtro === 'disponivel' ? 'active' : '' ?>">✅ Disponíveis</a>
        <a href="dispositivos.php?filtro=alugado"     class="btn btn-filter <?= $filtro === 'alugado'    ? 'active' : '' ?>">📱 Alugados</a>
    </div>

    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Marca</th>
                    <th>Modelo</th>
                    <th>Diária</th>
                    <th>Status</th>
                    <?php if ($isAdmin): ?><th>Ações</th><?php endif; ?>
                </tr>
            </thead>
            <tbody>
            <?php if ($dispositivos && $dispositivos->num_rows > 0):
                while ($d = $dispositivos->fetch_assoc()): ?>
                <tr>
                    <td><?= $d['id'] ?></td>
                    <td><?= htmlspecialchars($d['marca']) ?></td>
                    <td><?= htmlspecialchars($d['modelo']) ?></td>
                    <td><?= formatarMoeda($d['valor_diaria']) ?></td>
                    <td>
                        <?php if ($d['status'] === 'disponivel'): ?>
                            <span class="badge badge-green">Disponível</span>
                        <?php else: ?>
                            <span class="badge badge-orange">Alugado</span>
                        <?php endif; ?>
                    </td>
                    <?php if ($isAdmin): ?>
                    <td class="td-actions">
                        <a href="dispositivos.php?acao=editar&id=<?= $d['id'] ?>" class="btn btn-sm btn-info">✏️ Editar</a>
                        <?php if ($d['status'] === 'disponivel'): ?>
                            <button onclick="confirmarRemocao(<?= $d['id'] ?>, '<?= htmlspecialchars(addslashes($d['marca'] . ' ' . $d['modelo'])) ?>')"
                                    class="btn btn-sm btn-danger">🗑️ Remover</button>
                        <?php else: ?>
                            <button class="btn btn-sm btn-danger" disabled title="Não é possível remover um dispositivo alugado">🗑️ Remover</button>
                        <?php endif; ?>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endwhile; else: ?>
                <tr><td colspan="<?= $isAdmin ? 6 : 5 ?>" class="empty-msg">Nenhum dispositivo encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Form oculto para remoção -->
    <?php if ($isAdmin): ?>
    <form id="formRemover" action="dispositivo_action.php" method="POST" style="display:none;">
        <input type="hidden" name="acao" value="remover">
        <input type="hidden" name="id" id="remover_id" value="">
    </form>
    <?php endif; ?>

    <?php endif; ?>
</div>

<script src="script.js"></script>
</body>
</html>
