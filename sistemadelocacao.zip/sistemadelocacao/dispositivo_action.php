<?php
require_once 'config.php';
verificarAdmin(); // Apenas admin pode executar ações em dispositivos

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: dispositivos.php');
    exit;
}

$conn = conectar();
$acao = $_POST['acao'] ?? '';

// ── CADASTRAR ──────────────────────────────────────────────
if ($acao === 'cadastrar') {
    $marca        = sanitizar($conn, $_POST['marca'] ?? '');
    $modelo       = sanitizar($conn, $_POST['modelo'] ?? '');
    $valor_diaria = trim($_POST['valor_diaria'] ?? '');

    // Validações
    if (empty($marca) || empty($modelo) || empty($valor_diaria)) {
        $conn->close();
        header('Location: dispositivos.php?acao=novo&erro_msg=Preencha+todos+os+campos.');
        exit;
    }

    $valor_diaria = floatval(str_replace(',', '.', $valor_diaria));
    if ($valor_diaria <= 0) {
        $conn->close();
        header('Location: dispositivos.php?acao=novo&erro_msg=O+valor+da+diária+deve+ser+maior+que+zero.');
        exit;
    }

    $sql = "INSERT INTO dispositivos (marca, modelo, valor_diaria, status)
            VALUES ('$marca', '$modelo', $valor_diaria, 'disponivel')";

    if ($conn->query($sql)) {
        $conn->close();
        header('Location: dispositivos.php?msg=Dispositivo+cadastrado+com+sucesso.');
    } else {
        $conn->close();
        header('Location: dispositivos.php?acao=novo&erro_msg=Erro+ao+cadastrar+dispositivo.');
    }
    exit;
}

// ── EDITAR ─────────────────────────────────────────────────
if ($acao === 'editar') {
    $id           = (int)($_POST['id'] ?? 0);
    $marca        = sanitizar($conn, $_POST['marca'] ?? '');
    $modelo       = sanitizar($conn, $_POST['modelo'] ?? '');
    $valor_diaria = trim($_POST['valor_diaria'] ?? '');
    $status       = sanitizar($conn, $_POST['status'] ?? '');

    if ($id <= 0 || empty($marca) || empty($modelo) || empty($valor_diaria)) {
        $conn->close();
        header("Location: dispositivos.php?acao=editar&id=$id&erro_msg=Preencha+todos+os+campos.");
        exit;
    }

    $valor_diaria = floatval(str_replace(',', '.', $valor_diaria));
    if ($valor_diaria <= 0) {
        $conn->close();
        header("Location: dispositivos.php?acao=editar&id=$id&erro_msg=O+valor+da+diária+deve+ser+maior+que+zero.");
        exit;
    }

    $statusValidos = ['disponivel', 'alugado'];
    if (!in_array($status, $statusValidos)) {
        $conn->close();
        header("Location: dispositivos.php?acao=editar&id=$id&erro_msg=Status+inválido.");
        exit;
    }

    $sql = "UPDATE dispositivos SET marca='$marca', modelo='$modelo', valor_diaria=$valor_diaria, status='$status'
            WHERE id=$id";

    if ($conn->query($sql)) {
        $conn->close();
        header('Location: dispositivos.php?msg=Dispositivo+atualizado+com+sucesso.');
    } else {
        $conn->close();
        header("Location: dispositivos.php?acao=editar&id=$id&erro_msg=Erro+ao+atualizar+dispositivo.");
    }
    exit;
}

// ── REMOVER ────────────────────────────────────────────────
if ($acao === 'remover') {
    $id = (int)($_POST['id'] ?? 0);

    if ($id <= 0) {
        $conn->close();
        header('Location: dispositivos.php?erro_msg=ID+inválido.');
        exit;
    }

    // Verifica se está alugado
    $res = $conn->query("SELECT status FROM dispositivos WHERE id=$id LIMIT 1");
    $disp = $res ? $res->fetch_assoc() : null;

    if (!$disp) {
        $conn->close();
        header('Location: dispositivos.php?erro_msg=Dispositivo+não+encontrado.');
        exit;
    }

    if ($disp['status'] === 'alugado') {
        $conn->close();
        header('Location: dispositivos.php?erro_msg=Não+é+possível+remover+um+dispositivo+que+está+alugado.');
        exit;
    }

    if ($conn->query("DELETE FROM dispositivos WHERE id=$id")) {
        $conn->close();
        header('Location: dispositivos.php?msg=Dispositivo+removido+com+sucesso.');
    } else {
        $conn->close();
        header('Location: dispositivos.php?erro_msg=Erro+ao+remover+dispositivo.');
    }
    exit;
}

$conn->close();
header('Location: dispositivos.php');
exit;
?>
