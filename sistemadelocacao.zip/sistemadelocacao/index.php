<?php
require_once 'config.php';
verificarLogin();

$conn = conectar();

// Totais para o dashboard
$r = $conn->query("SELECT COUNT(*) as total FROM dispositivos WHERE status = 'disponivel'");
$totalDisponiveis = $r ? $r->fetch_assoc()['total'] : 0;

$r = $conn->query("SELECT COUNT(*) as total FROM dispositivos WHERE status = 'alugado'");
$totalAlugados = $r ? $r->fetch_assoc()['total'] : 0;

$r = $conn->query("SELECT COUNT(*) as total FROM locacoes WHERE status = 'ativa'");
$totalAtivas = $r ? $r->fetch_assoc()['total'] : 0;

$r = $conn->query("SELECT COUNT(*) as total FROM locacoes WHERE status = 'finalizada'");
$totalFinalizadas = $r ? $r->fetch_assoc()['total'] : 0;

// Locações com atraso
$hoje = date('Y-m-d');
$r = $conn->query("SELECT COUNT(*) as total FROM locacoes WHERE status = 'ativa' AND data_prevista_devolucao < '$hoje'");
$totalAtrasos = $r ? $r->fetch_assoc()['total'] : 0;

// Locações ativas recentes
$locacoesAtivas = $conn->query("
    SELECT l.*, d.modelo, d.marca, d.valor_diaria
    FROM locacoes l
    JOIN dispositivos d ON l.dispositivo_id = d.id
    WHERE l.status = 'ativa'
    ORDER BY l.data_prevista_devolucao ASC
    LIMIT 5
");

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard — ConectaFácil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
    <div class="page-header">
        <h2>Dashboard</h2>
        <p>Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']) ?></strong>
           <span class="badge badge-<?= $_SESSION['usuario_perfil'] === 'admin' ? 'admin' : 'operador' ?>">
               <?= $_SESSION['usuario_perfil'] === 'admin' ? 'Administrador' : 'Operador' ?>
           </span>
        </p>
    </div>

    <?php if (isset($_GET['erro']) && $_GET['erro'] === 'acesso_negado'): ?>
        <div class="alert alert-danger">Acesso negado. Você não tem permissão para acessar essa funcionalidade.</div>
    <?php endif; ?>

    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div>
    <?php endif; ?>

    <!-- Cards de resumo -->
    <div class="cards-grid">
        <div class="card card-green">
            <div class="card-icon">✅</div>
            <div class="card-info">
                <span class="card-number"><?= $totalDisponiveis ?></span>
                <span class="card-label">Disponíveis</span>
            </div>
        </div>
        <div class="card card-orange">
            <div class="card-icon">📱</div>
            <div class="card-info">
                <span class="card-number"><?= $totalAlugados ?></span>
                <span class="card-label">Alugados</span>
            </div>
        </div>
        <div class="card card-blue">
            <div class="card-icon">📋</div>
            <div class="card-info">
                <span class="card-number"><?= $totalAtivas ?></span>
                <span class="card-label">Locações Ativas</span>
            </div>
        </div>
        <div class="card card-gray">
            <div class="card-icon">🏁</div>
            <div class="card-info">
                <span class="card-number"><?= $totalFinalizadas ?></span>
                <span class="card-label">Finalizadas</span>
            </div>
        </div>
        <?php if ($totalAtrasos > 0): ?>
        <div class="card card-red">
            <div class="card-icon">⚠️</div>
            <div class="card-info">
                <span class="card-number"><?= $totalAtrasos ?></span>
                <span class="card-label">Em Atraso</span>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Ações rápidas -->
    <div class="section">
        <h3>Ações Rápidas</h3>
        <div class="actions-grid">
            <a href="locacoes.php?acao=nova" class="action-btn action-blue">
                <span>➕</span> Nova Locação
            </a>
            <a href="locacoes.php" class="action-btn action-teal">
                <span>📋</span> Ver Locações Ativas
            </a>
            <a href="dispositivos.php" class="action-btn action-green">
                <span>📱</span> Ver Dispositivos
            </a>
            <?php if ($_SESSION['usuario_perfil'] === 'admin'): ?>
            <a href="dispositivos.php?acao=novo" class="action-btn action-purple">
                <span>➕</span> Cadastrar Dispositivo
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Locações ativas recentes -->
    <div class="section">
        <h3>Locações Ativas <small>(próximas devoluções)</small></h3>
        <?php if ($locacoesAtivas && $locacoesAtivas->num_rows > 0): ?>
        <div class="table-wrapper">
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Dispositivo</th>
                        <th>Retirada</th>
                        <th>Devolução Prevista</th>
                        <th>Status</th>
                        <th>Ação</th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($loc = $locacoesAtivas->fetch_assoc()):
                    $atrasado = $loc['data_prevista_devolucao'] < $hoje;
                ?>
                    <tr class="<?= $atrasado ? 'row-atraso' : '' ?>">
                        <td><?= $loc['id'] ?></td>
                        <td><?= htmlspecialchars($loc['nome_cliente']) ?></td>
                        <td><?= htmlspecialchars($loc['marca'] . ' ' . $loc['modelo']) ?></td>
                        <td><?= formatarData($loc['data_retirada']) ?></td>
                        <td>
                            <?= formatarData($loc['data_prevista_devolucao']) ?>
                            <?php if ($atrasado): ?>
                                <span class="badge badge-red">ATRASO</span>
                            <?php endif; ?>
                        </td>
                        <td><span class="badge badge-ativa">Ativa</span></td>
                        <td>
                            <a href="devolucao.php?id=<?= $loc['id'] ?>" class="btn btn-sm btn-warning">Devolver</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>
        <a href="locacoes.php" class="link-ver-todos">Ver todas as locações →</a>
        <?php else: ?>
            <p class="empty-msg">Nenhuma locação ativa no momento.</p>
        <?php endif; ?>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>
