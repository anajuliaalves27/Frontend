<?php
require_once 'config.php';

// Se já está logado, redireciona para o dashboard
if (isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

$erro = isset($_GET['erro']) ? $_GET['erro'] : '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — ConectaFácil Locações</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">

<div class="login-container">
    <div class="login-logo">
        <div class="logo-icon">📱</div>
        <h1>ConectaFácil</h1>
        <p>Locações Tecnológicas</p>
    </div>

    <?php if ($erro === 'credenciais'): ?>
        <div class="alert alert-danger">E-mail ou senha incorretos.</div>
    <?php elseif ($erro === 'campos'): ?>
        <div class="alert alert-danger">Preencha todos os campos.</div>
    <?php endif; ?>

    <form action="logui_action.php" method="POST" class="login-form" id="formLogin">
        <div class="form-group">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" placeholder="seu@email.com" required autocomplete="email">
        </div>
        <div class="form-group">
            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" placeholder="••••••••" required autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-primary btn-block">Entrar</button>
    </form>

    <div class="login-hint">
        <p><strong>Admin:</strong> admin@conectafacil.com / admin123</p>
        <p><strong>Operador:</strong> operador@conectafacil.com / operador123</p>
    </div>
</div>

<script src="script.js"></script>
</body>
</html>
