<?php
$paginaAtual = basename($_SERVER['PHP_SELF']);
$isAdmin     = isset($_SESSION['usuario_perfil']) && $_SESSION['usuario_perfil'] === 'admin';
?>
<nav class="navbar">
    <div class="navbar-brand">
        <span class="navbar-icon">📱</span>
        <span>ConectaFácil</span>
    </div>

    <ul class="navbar-menu">
        <li>
            <a href="index.php" class="<?= $paginaAtual === 'index.php' ? 'active' : '' ?>">
                🏠 Dashboard
            </a>
        </li>
        <li>
            <a href="dispositivos.php" class="<?= $paginaAtual === 'dispositivos.php' ? 'active' : '' ?>">
                📱 Dispositivos
            </a>
        </li>
        <li>
            <a href="locacoes.php?filtro=ativas" class="<?= ($paginaAtual === 'locacoes.php' && ($filtro ?? '') !== 'finalizadas') ? 'active' : '' ?>">
                📋 Locações Ativas
            </a>
        </li>
        <li>
            <a href="locacoes.php?filtro=finalizadas" class="<?= ($paginaAtual === 'locacoes.php' && isset($_GET['filtro']) && $_GET['filtro'] === 'finalizadas') ? 'active' : '' ?>">
                🏁 Finalizadas
            </a>
        </li>
        <?php if ($isAdmin): ?>
        <li>
            <a href="locacoes.php?filtro=alugados" class="<?= ($paginaAtual === 'locacoes.php' && isset($_GET['filtro']) && $_GET['filtro'] === 'alugados') ? 'active' : '' ?>">
                🔒 Alugados
            </a>
        </li>
        <?php endif; ?>
    </ul>

    <div class="navbar-right">
        <button class="btn-theme" id="btnTema" title="Alternar tema claro/escuro">🌙</button>
        <span class="user-name">
            👤 <?= htmlspecialchars($_SESSION['usuario_nome'] ?? '') ?>
            <span class="badge badge-<?= $isAdmin ? 'admin' : 'operador' ?>" style="margin-left:6px;">
                <?= $isAdmin ? 'Admin' : 'Operador' ?>
            </span>
        </span>
        <a href="logout.php" class="btn-logout">Sair</a>
    </div>
</nav>
