<?php
// ============================================
// Configuração de Conexão com o Banco de Dados
// ConectaFácil Locações Tecnológicas
// ============================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'conectafacil');

// Configurações do sistema
define('TAXA_DANO', 150.00);          // Taxa fixa por dano ao aparelho
define('MULTA_DIARIA_ATRASO', 0.10); // 10% do valor da diária por dia de atraso

function conectar() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    $conn->set_charset('utf8mb4');

    if ($conn->connect_error) {
        die('<div style="font-family:sans-serif;padding:40px;text-align:center;">
            <h2 style="color:#e74c3c;">Erro de Conexão</h2>
            <p>Não foi possível conectar ao banco de dados.</p>
            <p><strong>Verifique se o MySQL está rodando e se o banco "conectafacil" foi criado.</strong></p>
            <p style="color:#999;font-size:13px;">Erro: ' . $conn->connect_error . '</p>
        </div>');
    }

    return $conn;
}

// Inicia sessão se ainda não iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Função para verificar se o usuário está logado
function verificarLogin() {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: loguin.php');
        exit;
    }
}

// Função para verificar se é administrador
function verificarAdmin() {
    verificarLogin();
    if ($_SESSION['usuario_perfil'] !== 'admin') {
        header('Location: index.php?erro=acesso_negado');
        exit;
    }
}

// Função para sanitizar entrada
function sanitizar($conn, $valor) {
    return $conn->real_escape_string(trim($valor));
}

// Função para formatar moeda
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Função para formatar data BR
function formatarData($data) {
    if (!$data || $data === '0000-00-00') return '-';
    return date('d/m/Y', strtotime($data));
}

// Função para calcular dias entre datas
function calcularDias($dataInicio, $dataFim) {
    $inicio = new DateTime($dataInicio);
    $fim = new DateTime($dataFim);
    $diff = $inicio->diff($fim);
    return max(1, $diff->days);
}
?>
