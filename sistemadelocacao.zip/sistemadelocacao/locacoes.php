<?php
require_once 'config.php';
verificarLogin();

$conn   = conectar();
$acao   = $_GET['acao']   ?? 'listar';
$filtro = $_GET['filtro'] ?? 'ativas';
$hoje   = date('Y-m-d');
$isAdmin = $_SESSION['usuario_perfil'] === 'admin';

// Dispositivos disponíveis para o formulário
$disponiveis = $conn->query("SELECT * FROM dispositivos WHERE status = 'disponivel' ORDER BY marca, modelo");

// Monta a query conforme filtro
if ($filtro === 'finalizadas') {
    $where     = "WHERE l.status = 'finalizada'";
    $orderBy   = "ORDER BY l.data_devolucao DESC";
} elseif ($filtro === 'alugados') {
    $where     = "WHERE l.status = 'ativa'";
    $orderBy   = "ORDER BY l.data_retirada DESC";
} else {
    $where     = "WHERE l.status = 'ativa'";
    $orderBy   = "ORDER BY l.data_prevista_devolucao ASC";
}

$locacoes = $conn->query("
    SELECT l.*, d.modelo, d.marca, d.valor_diaria
    FROM locacoes l
    JOIN dispositivos d ON l.dispositivo_id = d.id
    $where
    $orderBy
");

// Totais para os filtros
$totalAtivas      = $conn->query("SELECT COUNT(*) as t FROM locacoes WHERE status='ativa'")->fetch_assoc()['t'];
$totalFinalizadas = $conn->query("SELECT COUNT(*) as t FROM locacoes WHERE status='finalizada'")->fetch_assoc()['t'];
$totalAtrasos     = $conn->query("SELECT COUNT(*) as t FROM locacoes WHERE status='ativa' AND data_prevista_devolucao < '$hoje'")->fetch_assoc()['t'];

$conn->close();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Locações — ConectaFácil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">

    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-success">✅ <?= htmlspecialchars($_GET['msg']) ?></div>
    <?php endif; ?>
    <?php if (isset($_GET['erro_msg'])): ?>
        <div class="alert alert-danger">❌ <?= htmlspecialchars($_GET['erro_msg']) ?></div>
    <?php endif; ?>

    <?php if ($acao === 'nova'): ?>
    <!-- ── FORMULÁRIO NOVA LOCAÇÃO ── -->
    <div class="page-header">
        <div>
            <h2>Nova Locação</h2>
            <p>Preencha os dados para registrar uma nova locação</p>
        </div>
        <a href="locacoes.php" class="btn btn-secondary">← Voltar</a>
    </div>

    <div class="form-card">
        <?php if (!$disponiveis || $disponiveis->num_rows === 0): ?>
            <div class="alert alert-warning">⚠️ Não há dispositivos disponíveis para locação no momento.</div>
        <?php else: ?>
        <form action="locacao_action.php" method="POST" id="formLocacao">
            <input type="hidden" name="acao" value="registrar">

            <div class="form-group">
                <label for="nome_cliente">Nome do Cliente *</label>
                <input type="text" id="nome_cliente" name="nome_cliente" maxlength="150" required
                       placeholder="Nome completo do cliente">
            </div>

            <div class="form-group">
                <label for="dispositivo_id">Dispositivo *</label>
                <select id="dispositivo_id" name="dispositivo_id" required>
                    <option value="">— Selecione um dispositivo —</option>
                    <?php while ($d = $disponiveis->fetch_assoc()): ?>
                        <option value="<?= $d['id'] ?>" data-diaria="<?= $d['valor_diaria'] ?>">
                            <?= htmlspecialchars($d['marca'] . ' ' . $d['modelo']) ?> — R$ <?= number_format($d['valor_diaria'], 2, ',', '.') ?>/dia
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-row">
                <div class="form-group">
                    <label for="data_retirada">Data de Retirada *</label>
                    <input type="date" id="data_retirada" name="data_retirada" required
                           value="<?= $hoje ?>" min="<?= $hoje ?>">
                </div>
                <div class="form-group">
                    <label for="data_prevista_devolucao">Data Prevista de Devolução *</label>
                    <input type="date" id="data_prevista_devolucao" name="data_prevista_devolucao" required
                           min="<?= $hoje ?>">
                </div>
            </div>

            <div class="form-preview" id="previewValor" style="display:none;">
                💰 <strong>Estimativa:</strong>
                <span id="previewDias"></span> dias ×
                <span id="previewDiaria"></span> =
                <strong id="previewTotal"></strong>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">📋 Registrar Locação</button>
                <a href="locacoes.php" class="btn btn-secondary">Cancelar</a>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <?php else: ?>
    <!-- ── LISTAGEM ── -->
    <div class="page-header">
        <div>
            <h2>
                <?php if ($filtro === 'finalizadas'): ?>🏁 Locações Finalizadas
                <?php elseif ($filtro === 'alugados'): ?>🔒 Dispositivos Alugados
                <?php else: ?>📋 Locações Ativas
                <?php endif; ?>
            </h2>
            <p>
                <?= $totalAtivas ?> ativa(s) · <?= $totalFinalizadas ?> finalizada(s)
                <?php if ($totalAtrasos > 0): ?>
                    · <span style="color:var(--danger);">⚠️ <?= $totalAtrasos ?> em atraso</span>
                <?php endif; ?>
            </p>
        </div>
        <a href="locacoes.php?acao=nova" class="btn btn-primary">➕ Nova Locação</a>
    </div>

    <!-- Filtros -->
    <div class="filtros">
        <a href="locacoes.php?filtro=ativas"
           class="btn btn-filter <?= $filtro === 'ativas' ? 'active' : '' ?>">
            📋 Ativas <span style="opacity:.7;">(<?= $totalAtivas ?>)</span>
        </a>
        <a href="locacoes.php?filtro=finalizadas"
           class="btn btn-filter <?= $filtro === 'finalizadas' ? 'active' : '' ?>">
            🏁 Finalizadas <span style="opacity:.7;">(<?= $totalFinalizadas ?>)</span>
        </a>
        <?php if ($isAdmin): ?>
        <a href="locacoes.php?filtro=alugados"
           class="btn btn-filter <?= $filtro === 'alugados' ? 'active' : '' ?>">
            🔒 Alugados
        </a>
        <?php endif; ?>
    </div>

    <div class="table-wrapper">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Cliente</th>
                    <th>Dispositivo</th>
                    <th>Retirada</th>
                    <th>Dev. Prevista</th>
                    <?php if ($filtro === 'finalizadas'): ?>
                    <th>Dev. Real</th>
                    <th>Valor Total</th>
                    <th>Dano</th>
                    <?php endif; ?>
                    <th>Status</th>
                    <th>Ação</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($locacoes && $locacoes->num_rows > 0):
                while ($loc = $locacoes->fetch_assoc()):
                    $atrasado = ($filtro !== 'finalizadas') && ($loc['data_prevista_devolucao'] < $hoje);
            ?>
                <tr class="<?= $atrasado ? 'row-atraso' : '' ?>">
                    <td><strong>#<?= $loc['id'] ?></strong></td>
                    <td><?= htmlspecialchars($loc['nome_cliente']) ?></td>
                    <td>
                        <strong><?= htmlspecialchars($loc['marca']) ?></strong>
                        <?= htmlspecialchars($loc['modelo']) ?>
                        <br><small class="text-muted">R$ <?= number_format($loc['valor_diaria'], 2, ',', '.') ?>/dia</small>
                    </td>
                    <td><?= formatarData($loc['data_retirada']) ?></td>
                    <td>
                        <?= formatarData($loc['data_prevista_devolucao']) ?>
                        <?php if ($atrasado): ?>
                            <br><span class="badge badge-red">⚠️ ATRASO</span>
                        <?php endif; ?>
                    </td>
                    <?php if ($filtro === 'finalizadas'): ?>
                    <td><?= formatarData($loc['data_devolucao']) ?></td>
                    <td>
                        <strong><?= formatarMoeda($loc['valor_total']) ?></strong>
                        <?php if ($loc['multa_atraso'] > 0): ?>
                            <br><small class="text-red">+<?= formatarMoeda($loc['multa_atraso']) ?> multa</small>
                        <?php endif; ?>
                        <?php if ($loc['taxa_dano'] > 0): ?>
                            <br><small class="text-red">+<?= formatarMoeda($loc['taxa_dano']) ?> dano</small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?= $loc['houve_dano']
                            ? '<span class="badge badge-red">Sim</span>'
                            : '<span class="badge badge-green">Não</span>' ?>
                    </td>
                    <?php endif; ?>
                    <td>
                        <?php if ($loc['status'] === 'ativa'): ?>
                            <span class="badge badge-ativa">Ativa</span>
                        <?php else: ?>
                            <span class="badge badge-gray">Finalizada</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if ($loc['status'] === 'ativa'): ?>
                            <a href="devolucao.php?id=<?= $loc['id'] ?>" class="btn btn-sm btn-warning">↩️ Devolver</a>
                        <?php else: ?>
                            <span class="text-muted">—</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; else: ?>
                <tr>
                    <td colspan="10" class="empty-msg">
                        <?php if ($filtro === 'finalizadas'): ?>
                            Nenhuma locação finalizada ainda.
                        <?php elseif ($filtro === 'alugados'): ?>
                            Nenhum dispositivo alugado no momento.
                        <?php else: ?>
                            Nenhuma locação ativa no momento.
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<script src="script.js"></script>
</body>
</html>
