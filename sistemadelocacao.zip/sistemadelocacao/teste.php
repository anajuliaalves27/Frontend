<?php
/**
 * Página reservada a administradores (sem exposição de dados de sessão).
 */
require_once 'config.php';
verificarAdmin();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Área restrita — ConectaFácil</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container">
    <div class="section">
        <h3>Área de diagnóstico</h3>
        <p class="text-muted">Esta rota está restrita a administradores e não exibe dados sensíveis.</p>
        <p style="margin-top: 16px;"><a href="index.php" class="btn btn-primary">Ir para o Dashboard</a></p>
    </div>
</div>

</body>
</html>
