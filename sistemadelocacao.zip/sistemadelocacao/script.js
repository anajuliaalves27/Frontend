// ============================================
// ConectaFácil — Scripts do Sistema
// ============================================

document.addEventListener('DOMContentLoaded', function () {

    // ── Toggle Tema Claro / Escuro ─────────────
    var btnTema = document.getElementById('btnTema');
    var temaSalvo = localStorage.getItem('cf_tema') || 'dark';

    function aplicarTema(tema) {
        if (tema === 'light') {
            document.documentElement.setAttribute('data-theme', 'light');
            if (btnTema) btnTema.textContent = '☀️';
        } else {
            document.documentElement.removeAttribute('data-theme');
            if (btnTema) btnTema.textContent = '🌙';
        }
        localStorage.setItem('cf_tema', tema);
    }

    aplicarTema(temaSalvo);

    if (btnTema) {
        btnTema.addEventListener('click', function () {
            var atual = localStorage.getItem('cf_tema') || 'dark';
            aplicarTema(atual === 'dark' ? 'light' : 'dark');
        });
    }

    // ── Confirmação de remoção de dispositivo ──
    window.confirmarRemocao = function (id, nome) {
        if (confirm('Tem certeza que deseja remover o dispositivo:\n"' + nome + '"?\n\nEssa ação não pode ser desfeita.')) {
            document.getElementById('remover_id').value = id;
            document.getElementById('formRemover').submit();
        }
    };

    // ── Preview de valor na tela de nova locação ──
    var selDispositivo = document.getElementById('dispositivo_id');
    var inputRetirada  = document.getElementById('data_retirada');
    var inputDevolucao = document.getElementById('data_prevista_devolucao');
    var previewDiv     = document.getElementById('previewValor');

    function atualizarPreview() {
        if (!selDispositivo || !inputRetirada || !inputDevolucao || !previewDiv) return;

        var opt      = selDispositivo.options[selDispositivo.selectedIndex];
        var diaria   = parseFloat(opt ? opt.getAttribute('data-diaria') : 0) || 0;
        var retirada = inputRetirada.value;
        var devolucao= inputDevolucao.value;

        if (!diaria || !retirada || !devolucao) {
            previewDiv.style.display = 'none';
            return;
        }

        var d1   = new Date(retirada);
        var d2   = new Date(devolucao);
        var diff = Math.round((d2 - d1) / (1000 * 60 * 60 * 24));

        if (diff < 1) {
            previewDiv.style.display = 'none';
            return;
        }

        var total = diff * diaria;

        document.getElementById('previewDias').textContent   = diff;
        document.getElementById('previewDiaria').textContent = 'R$ ' + diaria.toFixed(2).replace('.', ',');
        document.getElementById('previewTotal').textContent  = 'R$ ' + total.toFixed(2).replace('.', ',');
        previewDiv.style.display = 'block';
    }

    if (selDispositivo) selDispositivo.addEventListener('change', atualizarPreview);
    if (inputRetirada)  inputRetirada.addEventListener('change', atualizarPreview);
    if (inputDevolucao) inputDevolucao.addEventListener('change', atualizarPreview);

    if (inputRetirada && inputDevolucao) {
        inputRetirada.addEventListener('change', function () {
            if (inputDevolucao.value && inputDevolucao.value < inputRetirada.value) {
                inputDevolucao.value = inputRetirada.value;
            }
            inputDevolucao.min = inputRetirada.value;
        });
    }

    // ── Cálculo dinâmico na tela de devolução ──
    var inputDataDev = document.getElementById('data_devolucao');
    var radiosDano   = document.querySelectorAll('input[name="houve_dano"]');

    function calcularDevolucao() {
        if (!inputDataDev || typeof valorDiaria === 'undefined') return;

        var dataDev = inputDataDev.value;
        if (!dataDev) return;

        var d1 = new Date(dataRetirada);
        var d2 = new Date(dataDev);
        var dp = new Date(dataPrevista);

        var diasReais  = Math.max(1, Math.round((d2 - d1) / (1000 * 60 * 60 * 24)));
        var base       = diasReais * valorDiaria;
        var multa      = 0;
        var diasAtraso = 0;

        if (d2 > dp) {
            diasAtraso = Math.round((d2 - dp) / (1000 * 60 * 60 * 24));
            multa = diasAtraso * valorDiaria * multaDiariaPerc;
        }

        var dano = 0;
        radiosDano.forEach(function (r) {
            if (r.checked && r.value === '1') dano = taxaDano;
        });

        var total = base + multa + dano;

        var elDias      = document.getElementById('calcDias');
        var elDiasLabel = document.getElementById('calcDiasLabel');
        var elBase      = document.getElementById('calcBase');
        var elMulta     = document.getElementById('calcMulta');
        var elAtraso    = document.getElementById('calcDiasAtraso');
        var rowMulta    = document.getElementById('rowMulta');
        var rowDano     = document.getElementById('rowDano');
        var elTotal     = document.getElementById('calcTotal');

        if (elDias)      elDias.textContent      = diasReais;
        if (elDiasLabel) elDiasLabel.textContent  = diasReais;
        if (elBase)      elBase.textContent       = 'R$ ' + base.toFixed(2).replace('.', ',');

        if (rowMulta) {
            if (multa > 0) {
                rowMulta.style.display = '';
                if (elAtraso) elAtraso.textContent = diasAtraso;
                if (elMulta)  elMulta.textContent  = 'R$ ' + multa.toFixed(2).replace('.', ',');
            } else {
                rowMulta.style.display = 'none';
            }
        }

        if (rowDano) rowDano.style.display = dano > 0 ? '' : 'none';
        if (elTotal) elTotal.innerHTML = '<strong>R$ ' + total.toFixed(2).replace('.', ',') + '</strong>';

        var hBase  = document.getElementById('hiddenBase');
        var hMulta = document.getElementById('hiddenMulta');
        var hDano  = document.getElementById('hiddenDano');
        var hTotal = document.getElementById('hiddenTotal');

        if (hBase)  hBase.value  = base.toFixed(2);
        if (hMulta) hMulta.value = multa.toFixed(2);
        if (hDano)  hDano.value  = dano.toFixed(2);
        if (hTotal) hTotal.value = total.toFixed(2);
    }

    if (inputDataDev) {
        inputDataDev.addEventListener('change', calcularDevolucao);
        calcularDevolucao();
    }

    radiosDano.forEach(function (r) {
        r.addEventListener('change', calcularDevolucao);
    });

    // ── Auto-dismiss de alertas de sucesso após 5s ──
    document.querySelectorAll('.alert-success').forEach(function (el) {
        setTimeout(function () {
            el.style.transition = 'opacity .5s';
            el.style.opacity = '0';
            setTimeout(function () { el.remove(); }, 500);
        }, 5000);
    });

    // ── Validação do formulário de login ──
    var formLogin = document.getElementById('formLogin');
    if (formLogin) {
        formLogin.addEventListener('submit', function (e) {
            var email = document.getElementById('email').value.trim();
            var senha = document.getElementById('senha').value.trim();
            if (!email || !senha) {
                e.preventDefault();
                alert('Preencha e-mail e senha.');
            }
        });
    }

});
