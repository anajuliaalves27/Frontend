<?php
// Script para criar os usuários no banco (senhas em texto puro)
// Acesse UMA VEZ pelo navegador: http://localhost/sistemadelocacao/gerar_senhas.php

require_once 'config.php';
$conn = conectar();

$usuarios = [
    ['Administrador', 'admin@conectafacil.com',    'admin123',    'admin'],
    ['Operador',      'operador@conectafacil.com', 'operador123', 'operador'],
];

echo '<h2>Criando usuários...</h2>';

foreach ($usuarios as $u) {
    $nome   = $conn->real_escape_string($u[0]);
    $email  = $conn->real_escape_string($u[1]);
    $senha  = $conn->real_escape_string($u[2]);
    $perfil = $conn->real_escape_string($u[3]);

    $conn->query("DELETE FROM usuarios WHERE email = '$email'");

    $sql = "INSERT INTO usuarios (nome, email, senha, perfil) VALUES ('$nome', '$email', '$senha', '$perfil')";
    if ($conn->query($sql)) {
        echo "<p>✅ Usuário <strong>{$u[0]}</strong> criado. Login: {$u[1]} / Senha: {$u[2]}</p>";
    } else {
        echo "<p>❌ Erro ao criar {$u[0]}: " . $conn->error . "</p>";
    }
}

$conn->close();
echo '<hr><p><strong>Pronto! Acesse <a href="loguin.php">loguin.php</a> para entrar.</strong></p>';
?>
